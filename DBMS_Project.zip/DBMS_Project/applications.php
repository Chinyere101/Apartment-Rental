<?php
session_start();
$formData = $_SESSION['form_data'] ?? [];
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$userId = $_SESSION['user_id'] ?? null;
$propertyName = isset($_GET['property']) ? urldecode($_GET['property']) : '';
$roommatesSelected = $_SESSION['selected_roommates'] ?? [];
$bedroomCount = $_POST['bedrooms'] ?? $_GET['bedrooms'] ?? 1;
$roommateList = '';
if (intval($bedroomCount) > 1 && is_array($roommatesSelected)) {
    $roommateList = implode(', ', $roommatesSelected);
}

$fullName = $age = '';
if ($userId) {
    $userRes = $mysqli->query("SELECT first_name, last_name, date_of_birth FROM users WHERE id = $userId");
    if ($userRes && $userRes->num_rows > 0) {
        $user = $userRes->fetch_assoc();
        $fullName = $user['first_name'] . ' ' . $user['last_name'];
        $dob = new DateTime($user['date_of_birth']);
        $today = new DateTime();
        $age = $today->diff($dob)->y;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Application - BEAPART</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .hidden { display: none; }
    .form-group { margin-bottom: 1rem; }
    .submit-btn {
      padding: 10px 20px;
      background: #d3a675;
      border: none;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      margin-top: 1rem;
    }
    .logout-btn {
      float: right;
      background: none;
      border: none;
      color: red;
      font-size: 1.2rem;
      cursor: pointer;
    }
    textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
  </style>
</head>
<body>
<header>
  <a href="index.html" class="logo"><img src="image/logo.png"></a>
  <ul class="navbar">
    <li><a href="index.html">Home</a></li>
    <li><a href="rent.php">Rent</a></li>
    <li><a href="roommates.php">Roommates</a></li>
    <li><a href="contact.html">Contact</a></li>
  </ul>
  <form action="logout.php" method="post" style="display:inline;">
    <button class="logout-btn" title="Logout">🔓</button>
  </form>
</header>

<section class="application-form">
  <h1>Application Form</h1>
  <form method="POST" action="application.php">
    <input type="hidden" name="property" value="<?= htmlspecialchars($propertyName) ?>">
    <input type="hidden" name="bedrooms" value="<?= htmlspecialchars($bedroomCount) ?>">
    
    <div class="form-section">
    <h2>Personal Information</h2>
    <div class="form-group">
        <input type="text" name="fullName" placeholder="Full Name" 
               value="<?= htmlspecialchars($formData['fullName'] ?? $fullName) ?>" required>
    </div>
    <div class="form-group">
        <input type="number" name="age" placeholder="Age" min="18" max="99"
               value="<?= htmlspecialchars($formData['age'] ?? $age) ?>" required>
    </div>
    <div class="form-group">
        <select name="year" required>
            <option value="">Select Academic Year</option>
            <option value="freshman" <?= ($formData['year'] ?? '') === 'freshman' ? 'selected' : '' ?>>Freshman</option>
            <option value="sophomore" <?= ($formData['year'] ?? '') === 'sophomore' ? 'selected' : '' ?>>Sophomore</option>
            <option value="junior" <?= ($formData['year'] ?? '') === 'junior' ? 'selected' : '' ?>>Junior</option>
            <option value="senior" <?= ($formData['year'] ?? '') === 'senior' ? 'selected' : '' ?>>Senior</option>
            <option value="graduate" <?= ($formData['year'] ?? '') === 'graduate' ? 'selected' : '' ?>>Graduate</option>
        </select>
    </div>
    <div class="form-group">
        <input type="text" name="major" placeholder="Major" 
               value="<?= htmlspecialchars($formData['major'] ?? '') ?>" required>
    </div>
    <div class="form-group">
        <select name="pets" required>
            <option value="">Do you have pets?</option>
            <option value="yes" <?= ($formData['pets'] ?? '') === 'yes' ? 'selected' : '' ?>>Yes</option>
            <option value="no" <?= ($formData['pets'] ?? '') === 'no' ? 'selected' : '' ?>>No</option>
        </select>
    </div>
    <div class="form-group">
        <select name="gender" required>
            <option value="">Gender</option>
            <option value="female" <?= ($formData['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Female</option>
            <option value="male" <?= ($formData['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Male</option>
            <option value="other" <?= ($formData['gender'] ?? '') === 'other' ? 'selected' : '' ?>>Other</option>
        </select>
    </div>
    <div class="form-group">
        <select name="studentType" required>
            <option value="">Student Type</option>
            <option value="local" <?= ($formData['studentType'] ?? '') === 'local' ? 'selected' : '' ?>>Local</option>
            <option value="international" <?= ($formData['studentType'] ?? '') === 'international' ? 'selected' : '' ?>>International</option>
        </select>
    </div>
</div>

<div class="form-section">
    <h2>Housing Info</h2>
    <div class="form-group">
        <input type="text" name="property" value="<?= htmlspecialchars($propertyName) ?>" readonly>
    </div>
    <div class="form-group">
        <label>Number of Bedrooms:</label>
        <input type="number" name="bedrooms" id="bedrooms" min="1" max="4" 
               value="<?= htmlspecialchars($formData['bedrooms'] ?? $bedroomCount) ?>" required 
               onchange="toggleRoommateSection(this.value)">
    </div>
    <div class="form-group">
        <label>Monthly Budget ($):</label>
        <input type="number" name="budget" min="500" max="2000" step="50"
               value="<?= htmlspecialchars($formData['budget'] ?? '') ?>" required>
    </div>
</div>

<div id="roommateSection" class="<?= (intval($bedroomCount) > 1) ? '' : 'hidden' ?>">
    <h2>Roommate Information</h2>
    <div class="form-group">
        <label>Need Roommates?</label>
        <select name="needRoommates" id="needRoommates" onchange="toggleRoommateSelection(this.value)" required>
            <option value="">Select an option</option>
            <option value="yes" <?= ($formData['needRoommates'] ?? '') === 'yes' ? 'selected' : '' ?>>Yes, I need roommates</option>
            <option value="no" <?= ($formData['needRoommates'] ?? '') === 'no' ? 'selected' : '' ?>>No, I already have roommates</option>
        </select>
    </div>
    
    <div id="selectRoommatesSection" class="<?= ($formData['needRoommates'] ?? '') === 'yes' ? '' : 'hidden' ?>">
        <button type="submit" formaction="save-session.php?property=<?= urlencode($propertyName) ?>" class="submit-btn">
            Select Roommates
        </button>
    </div>
    
    <div id="manualRoommatesSection" class="<?= ($formData['needRoommates'] ?? '') === 'no' ? '' : 'hidden' ?>">
        <div class="form-group">
            <label>Roommate Names (comma separated):</label>
            <textarea name="manualRoommates" rows="2"><?= htmlspecialchars($formData['manualRoommates'] ?? '') ?></textarea>
        </div>
    </div>
    
    <div class="form-group">
        <label>Selected Roommates:</label>
        <textarea name="roommatesList" rows="2" readonly><?= htmlspecialchars($roommateList) ?></textarea>
    </div>
</div>

<div class="form-section">
    <button type="submit" name="submit" class="submit-btn">Submit Application</button>
</div>
</div>

<script>
function toggleRoommateSection(val) {
    const roommateSection = document.getElementById("roommateSection");
    roommateSection.classList.toggle("hidden", parseInt(val) < 2);
    
    // Reset roommate selection when bedrooms change
    if (parseInt(val) < 2) {
        document.getElementById("needRoommates").value = "";
        document.querySelector('textarea[name="roommatesList"]').value = "";
    }
}

function toggleRoommateSelection(val) {
    const selectSection = document.getElementById("selectRoommatesSection");
    const manualSection = document.getElementById("manualRoommatesSection");
    
    selectSection.classList.toggle("hidden", val !== "yes");
    manualSection.classList.toggle("hidden", val !== "no");
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    toggleRoommateSection(document.getElementById('bedrooms').value);
});
</script>
</body>
</html>
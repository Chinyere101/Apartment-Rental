<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['form_data'] = $_POST;
    
    $queryParams = [
        'gender' => $_POST['gender'] ?? '',
        'pets' => $_POST['pets'] ?? '',
        'budget' => $_POST['budget'] ?? '',
        'bedrooms' => $_POST['bedrooms'] ?? 1,
        'property' => $_POST['property'] ?? ''
    ];
    
    $queryParams = array_merge($queryParams, $_GET);
    header("Location: roommates.php?" . http_build_query($queryParams));
    exit();
}
?>
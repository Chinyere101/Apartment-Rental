<?php
session_start();
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($userId, $storedPassword);
        $stmt->fetch();
        if ($password === $storedPassword) {
            $_SESSION['user_id'] = $userId;
            $_SESSION['user_email'] = $email;
            header("Location: role-selection.html");
            exit();
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "No user found with that email.";
    }
    $stmt->close();
}
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - BEAPART</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="login-section">
    <div class="login-container">
        <h1>Welcome Back</h1>
        <h2>Login to Your Account</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="POST" action="login.php" class="login-form">
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
        <p style="margin-top: 15px; text-align: center;">
            Don’t have an account yet? <a href="signup.php">Create an account</a>
        </p>
    </div>
</section>
</body>
</html>


<?php
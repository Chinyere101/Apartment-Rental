<?php
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$query = "SELECT * FROM properties WHERE status = 'Available' ORDER BY id DESC"; 
$result = $mysqli->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEAPART - Find Your Home</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body>

<header>
    <a href="index.html" class="logo">
        <img src="image/logo.png">
    </a>
    <ul class="navbar">
        <li><a href="index.html">Home</a></li>
        <li><a href="rent.php" class="active">Rent</a></li>
        <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="h-btn">
        <a href="login.html" class="h-btn1">Logout</a>
        <div class="bx bx-menu" id="menu-icon"></div>
    </div>
</header>

<section class="property-filters">
    <div class="filter-container">
        <h2>Find Your Perfect Home</h2>
    </div>
</section>

<section class="property-listings">
    <div class="listing-container">
        <div class="listing-header">
            <h3>Available Properties</h3>
        </div>

        <div class="listings-grid">
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $propertyName = htmlspecialchars($row['name']);
                    $address = htmlspecialchars($row['address']);
                    $price = number_format($row['price']);
                    $bedrooms = (int)$row['bedrooms'];
                    $size = (int)$row['size'];
                    $imagePath = !empty($row['image_path']) ? $row['image_path'] : 'image/default-property.jpg'; // fallback image
                    
                    echo "
                    <div class='property-card' data-aos='fade-up'>
                        <div class='property-img'>
                            <img src='$imagePath' alt='$propertyName'>
                            <span class='status-badge available'>Available</span>
                        </div>
                        <div class='property-details'>
                            <h4>$propertyName</h4>
                            <p><i class='bx bx-map'></i> $address</p>
                            <div class='property-features'>
                                <span><i class='bx bx-bed'></i> $bedrooms Beds</span>
                                <span><i class='bx bx-ruler'></i> $size sqft</span>
                            </div>
                            <div class='property-footer'>
                                <span class='price'>\$$price/month</span>
                                <a href='property-detail.php?id={$row['id']}' class='view-btn'>View Details</a>
                            </div>
                        </div>
                    </div>
                    ";
                }
            } else {
                echo "<p>No properties available at the moment. Check back later!</p>";
            }
            ?>
        </div>
    </div>
</section>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init({
        offset: 100,
        duration: 800
    });
</script>
<script src="js/script.js"></script>
</body>
</html>

<?php
$mysqli->close();
?>

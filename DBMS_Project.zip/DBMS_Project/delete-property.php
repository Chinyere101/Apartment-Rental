<?php
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$id = $_GET['id'];
$stmt = $mysqli->prepare("DELETE FROM properties WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
$mysqli->close();

$return = $_GET['return'] ?? 'list-property.php';
header("Location: $return");
exit();

?>

<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['selected_roommates'] = $_POST['roommate_names'] ?? [];
    
    if (isset($_SESSION['form_data'])) {
        $_SESSION['form_data']['roommatesList'] = implode(', ', $_SESSION['selected_roommates']);
    }
    
    header("Location: applications.php?" . http_build_query($_GET));
    exit();
}
?>
<?php
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $mysqli->real_escape_string($_POST["name"]);
    $email = $mysqli->real_escape_string($_POST["email"]);
    $subject = $mysqli->real_escape_string($_POST["subject"]);
    $message = $mysqli->real_escape_string($_POST["message"]);

    $stmt = $mysqli->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Thank you for contacting us!'); window.location.href = 'contact.html';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}

$mysqli->close();
?>

import mysql.connector
from faker import Faker
import random
from datetime import datetime, timedelta

faker = Faker()

def insert_roommates(n):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123Onyinye.",
        database="beapart"
    )
    cursor = conn.cursor()

    insert_query = """
    INSERT INTO roommates 
    (full_name, age, academic_year, major, pets, gender, student_type, budget, preferred_movein, user_id)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    years = ["freshman", "sophomore", "junior", "senior", "graduate"]
    majors = ["Computer Science", "Business", "Biology", "Engineering", "Psychology", "Economics"]
    pets_options = ["yes", "no"]
    genders = ["female", "male", "other"]
    student_types = ["local", "international"]

    for i in range(n):
        full_name = faker.name()
        age = random.randint(18, 30)
        academic_year = random.choice(years)
        major = random.choice(majors)
        pets = random.choice(pets_options)
        gender = random.choice(genders)
        student_type = random.choice(student_types)
        budget = random.choice([500, 600, 700, 800])
        preferred_movein = (datetime.now() + timedelta(days=random.randint(30, 180))).strftime('%Y-%m-%d')
        user_id = random.randint(1, 10)  # Ensure user IDs exist

        cursor.execute(insert_query, (
            full_name, age, academic_year, major, pets,
            gender, student_type, budget, preferred_movein, user_id
        ))

        print(f"Inserted: {full_name}, {major}, {academic_year}, Budget: {budget}")

    conn.commit()
    cursor.close()
    conn.close()
    print(f"Inserted {n} roommates.")

insert_roommates(100)

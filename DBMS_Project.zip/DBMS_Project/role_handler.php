<?php
session_start();
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? '';
    $company = $_POST['company_name'] ?? null;
    $ssn = $_POST['ssn'] ?? null;
    $userId = $_SESSION['user_id'] ?? null;

    if (!$userId) {
        echo "User not logged in.";
        exit();
    }

    $updateStatus = $mysqli->prepare("UPDATE users SET status = ? WHERE id = ?");
    $updateStatus->bind_param("si", $role, $userId);
    $updateStatus->execute();
    $updateStatus->close();

    if ($role === 'tenant') {

        $checkTenant = $mysqli->prepare("SELECT tenant_id FROM tenants WHERE user_id = ?");
        $checkTenant->bind_param("i", $userId);
        $checkTenant->execute();
        $checkTenant->store_result();

        if ($checkTenant->num_rows === 0) {
            $insertTenant = $mysqli->prepare("INSERT INTO tenants (user_id) VALUES (?)");
            $insertTenant->bind_param("i", $userId);
            $insertTenant->execute();
            $insertTenant->close();
        }
        $checkTenant->close();

        header("Location: rent.php");
        exit();

    } elseif ($role === 'landlord') {
        if ($company && $ssn) {
        
            $checkSSN = $mysqli->prepare("SELECT landlord_id FROM landlords WHERE ssn = ?");
            $checkSSN->bind_param("s", $ssn);
            $checkSSN->execute();
            $checkSSN->store_result();

            if ($checkSSN->num_rows === 0) {
          
                $getName = $mysqli->prepare("SELECT CONCAT(first_name, ' ', last_name) FROM users WHERE id = ?");
                $getName->bind_param("i", $userId);
                $getName->execute();
                $getName->bind_result($fullName);
                $getName->fetch();
                $getName->close();

                $insertLandlord = $mysqli->prepare("INSERT INTO landlords (user_id, name, company_name, ssn) VALUES (?, ?, ?, ?)");
                $insertLandlord->bind_param("isss", $userId, $fullName, $company, $ssn);
                $insertLandlord->execute();
                $insertLandlord->close();
            }
            $checkSSN->close();
        }

        header("Location: list-property.php");
        exit();

    } else {
        echo "Invalid role.";
    }
} else {
    header("Location: role-selection.html");
    exit();
}

$mysqli->close();
?>

import mysql.connector
import random
import string
from faker import Faker
from datetime import datetime

fake = Faker()

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='123Onyinye.',
    database='beapart'
)
cursor = conn.cursor()

academic_years = ['freshman', 'sophomore', 'junior', 'senior', 'graduate']
majors = ['Computer Science', 'Business', 'Psychology', 'Biology', 'Engineering', 'Economics']
genders = ['male', 'female', 'other']
student_types = ['local', 'international']
statuses = ['tenant', 'landlord', 'both']

def generate_password():
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choices(chars, k=10))

def generate_phone():
    return ''.join(random.choices(string.digits, k=10))

for _ in range(150):
    first = fake.first_name()
    last = fake.last_name()
    email = fake.unique.email()
    dob = fake.date_of_birth(minimum_age=18, maximum_age=30)
    phone = generate_phone()
    password = generate_password()
    status = random.choice(statuses)

    cursor.execute("""
        INSERT INTO users (first_name, last_name, date_of_birth, email, phone, password, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (first, last, dob, email, phone, password, status))
    user_id = cursor.lastrowid

    full_name = f"{first} {last}"
    age = datetime.now().year - dob.year
    year = random.choice(academic_years)
    major = random.choice(majors)
    pets = random.choice(['yes', 'no'])
    gender = random.choice(genders)
    student_type = random.choice(student_types)
    property_name = random.choice(['Thrive Student Living', 'Heritage Apartments', 'The Wyatt'])
    bedrooms = random.randint(1, 4)
    roommate_needed = 'yes' if bedrooms > 1 else 'no'
    roommate_names = None

    cursor.execute("""
        INSERT INTO applications (
            user_id, full_name, age, academic_year, major, pets, gender, student_type,
            property, bedrooms, roommate_needed, roommate_names
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        user_id, full_name, age, year, major, pets, gender, student_type,
        property_name, bedrooms, roommate_needed, roommate_names
    ))
    application_id = cursor.lastrowid

    if status in ['tenant', 'both']:
        cursor.execute("""
            INSERT INTO tenants (user_id, application_id, registered_at)
            VALUES (%s, %s, NOW())
        """, (user_id, application_id))

    if status in ['landlord', 'both']:
        ssn = ''.join(random.choices(string.digits, k=9))
        company = fake.company()
        name = f"{first} {last}"
        cursor.execute("""
            INSERT INTO landlords (user_id, name, company_name, ssn, registered_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, (user_id, name, company, ssn))

    conn.commit()

print("Generated Successfully")
cursor.close()
conn.close()

<?php
session_start();
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$fullName = $_POST['fullName'];
$age = $_POST['age'];
$academicYear = $_POST['year'];
$major = $_POST['major'];
$pets = $_POST['pets'];
$gender = $_POST['gender'];
$studentType = $_POST['studentType'];
$property = $_POST['property'];
$bedrooms = $_POST['bedrooms'];
$budget = $_POST['budget'];
$roommates = $_POST['roommatesList'] ?? '';

$stmt = $mysqli->prepare("INSERT INTO applications (full_name, age, academic_year, major, pets, gender, student_type, property, bedrooms, roommate_needed, roommate_names) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$roommateNeeded = ($bedrooms > 1) ? 'yes' : 'no';
$stmt->bind_param("sissssssiss", $fullName, $age, $academicYear, $major, $pets, $gender, $studentType, $property, $bedrooms, $roommateNeeded, $roommates);
$stmt->execute();
$stmt->close();

if (isset($_SESSION['user_id'])) {
    $applicationId = $mysqli->insert_id;
    $userId = $_SESSION['user_id'];
    $insert = $mysqli->prepare("INSERT INTO tenants (user_id, application_id) VALUES (?, ?)");
    $insert->bind_param("ii", $userId, $applicationId);
    $insert->execute();
    $insert->close();
}

unset($_SESSION['selected_roommates']);

header("Location: rent.php");
exit();
?>

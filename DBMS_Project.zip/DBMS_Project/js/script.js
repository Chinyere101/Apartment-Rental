// Header Sticky and Mobile Menu
const header = document.querySelector("header");
const menu = document.querySelector("#menu-icon");
const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", function() {
    header.classList.toggle("sticky", window.scrollY > 80);
});

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
};

window.onscroll = () => {
    menu.classList.remove('bx-x');
    navbar.classList.remove('open');
};

// Application Form Handling
document.addEventListener('DOMContentLoaded', function() {
    // Initialize roommate section based on bedroom count
    const bedroomsInput = document.getElementById('bedrooms');
    if (bedroomsInput) {
        toggleRoommateSection(bedroomsInput.value);
    }

    // Form validation
    const applicationForm = document.querySelector('.application-form form');
    if (applicationForm) {
        applicationForm.addEventListener('submit', function(e) {
            const bedrooms = parseInt(document.querySelector('[name="bedrooms"]').value);
            const needRoommates = document.querySelector('[name="needRoommates"]').value;
            
            if (bedrooms > 1 && needRoommates === '') {
                e.preventDefault();
                alert('Please select whether you need roommates');
                return false;
            }
            
            if (bedrooms > 1 && needRoommates === 'no' && 
                !document.querySelector('[name="manualRoommates"]').value.trim()) {
                e.preventDefault();
                alert('Please enter your roommates names');
                return false;
            }
            
            return true;
        });
    }
});

function toggleRoommateSection(val) {
    const roommateSection = document.getElementById("roommateSection");
    if (!roommateSection) return;
    
    roommateSection.classList.toggle("hidden", parseInt(val) < 2);
    
    // Reset roommate selection when bedrooms change to 1
    if (parseInt(val) < 2) {
        document.getElementById("needRoommates").value = "";
        document.querySelector('textarea[name="roommatesList"]').value = "";
    }
}

function toggleRoommateSelection(val) {
    const selectSection = document.getElementById("selectRoommatesSection");
    const manualSection = document.getElementById("manualRoommatesSection");
    
    if (selectSection && manualSection) {
        selectSection.classList.toggle("hidden", val !== "yes");
        manualSection.classList.toggle("hidden", val !== "no");
        
        // Clear the opposite field when switching
        if (val === "yes") {
            document.querySelector('textarea[name="manualRoommates"]').value = "";
        } else if (val === "no") {
            document.querySelector('textarea[name="roommatesList"]').value = "";
        }
    }
}

// Property Search and Filter Functionality
document.addEventListener('DOMContentLoaded', function() {
    const properties = [
        {
            id: 1,
            name: "Thrive Student Living",
            address: "210 N Winston Ave, Lubbock, TX",
            price: 950,
            beds: 2,
            baths: 2,
            sqft: 850,
            type: "Apartment",
            status: "available",
            image: "image/apartments/p1.jpg"
        },
        {
            id: 2,
            name: "Park East Apartments",
            address: "1819 Glenna Blvd, Lubbock, TX",
            price: 750,
            beds: 1,
            baths: 1,
            sqft: 600,
            type: "Apartment",
            status: "available",
            image: "image/apartments/p2.jpg"
        },
        {
            id: 3,
            name: "The Holly",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 850,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/holly.jpeg"
        },
        {
            id: 4,
            name: "Scarlet",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 800,
            beds: 3,
            baths: 3,
            sqft: 1200,
            type: "Apartment",
            status: "available",
            image: "image/apartments/scarlet.jpg"
        },
        {
            id: 5,
            name: "The Wyatt",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 900,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/wyatt.png"
        },
        {
            id: 6,
            name: "Raider Pass",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 950,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/raider.jpg"
        },
        {
            id: 7,
            name: "The One",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 1000,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/one.avif"
        },
        {
            id: 8,
            name: "21 Hundred",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 1100,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/21hun.avif"
        },
        {
            id: 9,
            name: "Collective",
            address: "2401 Glenna Goodacre Blvd, Lubbock, TX",
            price: 1200,
            beds: 4,
            baths: 4,
            sqft: 1400,
            type: "Apartment",
            status: "available",
            image: "image/apartments/collect.jpg"
        }
    ];

    // Roommate data
    const roommates = [
        {
            id: 1,
            name: "Alex Johnson",
            age: 22,
            major: "Computer Science",
            moveIn: "August 2025",
            budget: 700,
            match: 85,
            image: "image/roommate1.jpg"
        },
        {
            id: 2,
            name: "Sarah Williams",
            age: 21,
            major: "Business Administration",
            moveIn: "July 2025",
            budget: 650,
            match: 78,
            image: "image/roommate2.jpg"
        }
    ];

    // Property Search Filters
    const propertySearchForms = document.querySelectorAll('.filter-form');
    propertySearchForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const propertyName = form.querySelector('#propertyName') ? form.querySelector('#propertyName').value : 'any';
            const priceRange = form.querySelector('#priceRange') ? form.querySelector('#priceRange').value : 'any';
            const bedrooms = form.querySelector('#bedrooms') ? form.querySelector('#bedrooms').value : 'any';
            
            // Filter properties
            const filtered = properties.filter(property => {
                // Property name filter
                let nameMatch = true;
                if (propertyName !== 'any') {
                    const nameMap = {
                        'thrive': 'thrive student living',
                        'park': 'park east apartments',
                        'holly': 'the holly',
                        'scarlet': 'scarlet',
                        'wyatt': 'the wyatt',
                        'raider': 'raider pass',
                        'one': 'the one',
                        'hundred': '21 hundred',
                        'collective': 'collective'
                    };
                    nameMatch = property.name.toLowerCase().includes(nameMap[propertyName]);
                }
                
                // Price range filter
                let priceMatch = true;
                if (priceRange !== 'any') {
                    const [min, max] = priceRange === '1200+' ? [1200, Infinity] : priceRange.split('-').map(Number);
                    priceMatch = property.price >= min && property.price <= max;
                }
                
                // Bedrooms filter
                let bedMatch = true;
                if (bedrooms !== 'any') {
                    if (bedrooms === '3+') {
                        bedMatch = property.beds >= 3;
                    } else {
                        bedMatch = property.beds == bedrooms;
                    }
                }
                
                return nameMatch && priceMatch && bedMatch;
            });
            
            // Update UI with filtered results
            updatePropertyResults(filtered);
        });
    });

    // Roommate Search Filters
    const roommateSearchForms = document.querySelectorAll('.search-form');
    roommateSearchForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const gender = this.querySelector('select:nth-of-type(1)').value;
            const ageRange = this.querySelector('select:nth-of-type(2)').value;
            const budgetRange = this.querySelector('select:nth-of-type(3)').value;
            
            // Filter roommates
            const filtered = roommates.filter(roommate => {
                // Gender filter (in real app would have gender property)
                const genderMatch = gender === "No Preference" || true;
                
                // Age range filter
                let ageMatch = true;
                if (ageRange !== "Any") {
                    const [min, max] = ageRange.split('-').map(Number);
                    ageMatch = roommate.age >= min && roommate.age <= max;
                }
                
                // Budget range filter
                let budgetMatch = true;
                if (budgetRange !== "Any") {
                    const [min, max] = budgetRange.replace('$', '').split('-').map(Number);
                    budgetMatch = roommate.budget >= min && roommate.budget <= max;
                }
                
                return genderMatch && ageMatch && budgetMatch;
            });
            
            updateRoommateResults(filtered);
        });
    });

    // Sort Functionality
    const sortSelects = document.querySelectorAll('.sort-options select');
    sortSelects.forEach(select => {
        select.addEventListener('change', function() {
            const sortValue = this.value;
            let sortedProperties = [...properties];
            
            switch(sortValue) {
                case "Price (Low to High)":
                    sortedProperties.sort((a, b) => a.price - b.price);
                    break;
                case "Price (High to Low)":
                    sortedProperties.sort((a, b) => b.price - a.price);
                    break;
                case "Newest":
                    sortedProperties.sort((a, b) => b.id - a.id);
                    break;
                case "Best Match":
                    break;
            }
            
            if (this.closest('.property-listings')) {
                updatePropertyResults(sortedProperties);
            } else if (this.closest('.roommate-listings')) {
                updateRoommateResults(sortedProperties);
            }
        });
    });

    // Update Property Results in UI
    function updatePropertyResults(filteredProperties) {
        const listingsGrid = document.querySelector('.listings-grid');
        if (!listingsGrid) return;
        
        listingsGrid.innerHTML = '';
        
        filteredProperties.forEach(property => {
            const card = document.createElement('div');
            card.className = 'property-card';
            card.innerHTML = `
                <div class="property-img">
                    <img src="${property.image}" alt="${property.name}">
                    <span class="status-badge ${property.status}">${property.status.charAt(0).toUpperCase() + property.status.slice(1)}</span>
                </div>
                <div class="property-details">
                    <h4>${property.name}</h4>
                    <p><i class='bx bx-map'></i> ${property.address}</p>
                    <div class="property-features">
                        <span><i class='bx bx-bed'></i> ${property.beds} Bed${property.beds > 1 ? 's' : ''}</span>
                        <span><i class='bx bx-bath'></i> ${property.baths} Bath${property.baths > 1 ? 's' : ''}</span>
                        <span><i class='bx bx-ruler'></i> ${property.sqft} sqft</span>
                    </div>
                    <div class="property-footer">
                        <span class="price">$${property.price}/month</span>
                        <a href="property-detail.html?id=${property.id}" class="view-btn">View Details</a>
                    </div>
                </div>
            `;
            listingsGrid.appendChild(card);
        });
    }

    // Update Roommate Results in UI
    function updateRoommateResults(filteredRoommates) {
        const roommatesGrid = document.querySelector('.roommates-grid');
        if (!roommatesGrid) return;
        
        roommatesGrid.innerHTML = '';
        
        filteredRoommates.forEach(roommate => {
            const card = document.createElement('div');
            card.className = 'roommate-card';
            card.innerHTML = `
                <div class="roommate-img">
                    <img src="${roommate.image}" alt="${roommate.name}">
                </div>
                <div class="roommate-details">
                    <h4>${roommate.name} <span class="age">${roommate.age}</span></h4>
                    <p><i class='bx bx-book'></i> ${roommate.major}</p>
                    <div class="roommate-features">
                        <span><i class='bx bx-calendar'></i> Move-in: ${roommate.moveIn}</span>
                        <span><i class='bx bx-dollar'></i> Budget: $${roommate.budget}</span>
                    </div>
                    <div class="roommate-footer">
                        <div class="compatibility">
                            <div class="compat-bar" style="width: ${roommate.match}%"></div>
                            <span>${roommate.match}% Match</span>
                        </div>
                        <a href="#" class="connect-btn">Connect</a>
                    </div>
                </div>
            `;
            roommatesGrid.appendChild(card);
        });
    }

    // Property Detail Page - Load specific property
    if (document.querySelector('.property-detail')) {
        const urlParams = new URLSearchParams(window.location.search);
        const propertyId = urlParams.get('id');
        
        if (propertyId) {
            const property = properties.find(p => p.id == propertyId);
            if (property) {
                // Update the property detail page with the found property
                document.querySelector('.property-info h1').textContent = property.name;
                document.querySelector('.location').innerHTML = `<i class='bx bx-map'></i> ${property.address}`;
                document.querySelector('.price').textContent = `$${property.price}/month`;
                // Update other property details similarly...
            }
        }
    }

    
});


// Header Mobile Menu
menu.onclick = () => {
    menu.classList.toggle("bx-x");
    navbar.classList.toggle("open");
};
window.onscroll = () => {
    menu.classList.remove("bx-x");
    navbar.classList.remove("open");
};


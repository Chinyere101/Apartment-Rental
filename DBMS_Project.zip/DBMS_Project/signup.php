<?php
session_start();
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $dob = $_POST['date_of_birth'];
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);

    $check = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "Email already registered.";
    } else {
        $insert = $mysqli->prepare("INSERT INTO users (first_name, last_name, date_of_birth, email, phone, password, status) VALUES (?, ?, ?, ?, ?, ?, NULL)");
        $insert->bind_param("ssssss", $first, $last, $dob, $email, $phone, $password);
        if ($insert->execute()) {
            $_SESSION['user_id'] = $insert->insert_id;
            $_SESSION['user_email'] = $email;
            header("Location: login.php");
            exit();
        } else {
            echo "Signup error: " . $insert->error;
        }
        $insert->close();
    }
    $check->close();
}
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="login-section">
    <div class="login-container">
        <h1>Create Account</h1>
        <h2>Join BEAPART Today</h2>
        <form method="POST" action="signup.php" class="signup-form">
            <div class="form-row">
                <div class="form-group">
                    <label>First Name:</label>
                    <input type="text" name="first_name" required>
                </div>
                <div class="form-group">
                    <label>Last Name:</label>
                    <input type="text" name="last_name" required>
                </div>
            </div>
            <div class="form-group">
                <label>Date of Birth:</label>
                <input type="date" name="date_of_birth" required>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <input type="text" name="phone" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="signup-btn">Sign Up</button>
        </form>
        <p style="margin-top: 15px; text-align: center;">
            Already have an account? <a href="login.php">Login</a>
        </p>
    </div>
</section>
</body>
</html>

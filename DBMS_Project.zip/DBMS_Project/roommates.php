<?php
session_start();
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$gender = $_GET['gender'] ?? '';
$pets = $_GET['pets'] ?? '';
$budget = $_GET['budget'] ?? '';
$bedrooms = intval($_GET['bedrooms'] ?? 1);
$maxSelectable = max(0, $bedrooms - 1);

$query = "SELECT * FROM roommates WHERE 1=1";
$params = [];
$types = "";

if ($gender !== '') {
    $query .= " AND gender = ?";
    $params[] = $gender;
    $types .= "s";
}
if ($pets !== '') {
    $query .= " AND pets = ?";
    $params[] = $pets;
    $types .= "s";
}
if ($budget !== '') {
    $query .= " AND budget <= ?";
    $params[] = $budget;
    $types .= "i";
}

$stmt = $mysqli->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Handle selection
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['selected_roommates'] = $_POST['roommate_names'] ?? [];
    header("Location: applications.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Select Roommates</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .roommates-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      justify-content: center;
    }
    .roommate-card {
      border: 1px solid #ccc;
      padding: 1rem;
      border-radius: 10px;
      width: 300px;
      background-color: #fff;
    }
    .submit-btn {
      display: block;
      margin: 2rem auto;
      background-color: #d3a675;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<h2 style="text-align:center;">Choose up to <?= $maxSelectable ?> Roommate(s)</h2>

<form method="POST" action="confirm_roommate.php?<?= htmlspecialchars(http_build_query($_GET)) ?>">
  <div class="roommates-grid">
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="roommate-card">
        <label>
          <input type="checkbox" name="roommate_names[]" value="<?= htmlspecialchars($row['full_name']) ?>">
          <strong><?= htmlspecialchars($row['full_name']) ?></strong><br>
          <?= htmlspecialchars($row['major']) ?> (<?= htmlspecialchars($row['academic_year']) ?>)<br>
          Budget: $<?= htmlspecialchars($row['budget']) ?><br>
          Pets: <?= htmlspecialchars($row['pets']) ?> | Gender: <?= htmlspecialchars($row['gender']) ?>
        </label>
      </div>
    <?php endwhile; ?>
  </div>

  <button type="submit" class="submit-btn">Confirm Roommates</button>
</form>

<script>
const checkboxes = document.querySelectorAll('input[type="checkbox"]');
const max = <?= $maxSelectable ?>;
checkboxes.forEach(box => {
  box.addEventListener('change', () => {
    const selected = document.querySelectorAll('input[type="checkbox"]:checked');
    if (selected.length > max) {
      box.checked = false;
      alert("You can only select up to " + max + " roommate(s).");
    }
  });
});
</script>

</body>
</html>

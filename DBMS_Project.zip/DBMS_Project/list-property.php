<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$query = "SELECT * FROM properties";
$result = $mysqli->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Park East - BEAPART</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>
<header>
    <a href="index.html" class="logo"><img src="../image/logo.png"></a>
    <ul class="navbar">
        <li><a href="index.html">Home</a></li>
        <li><a href="rent.php">Rent</a></li>
        <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="h-btn">
        <a href="login.html" class="h-btn1">Logout</a>
        <div class="bx bx-menu" id="menu-icon"></div>
    </div>
</header>
<br>
    <div class="add-property-btn-container">
        <a href="add-property.php" class="add-property-btn">+ Add New Property</a>
    </div>
<section class="custom-property-listings">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $statusClass = strtolower($row['status']) === 'available' ? 'property-available' : 'property-unavailable';
            echo "
            
                <div class='custom-property-card' id='property-{$row['id']}'>
                    <div class='custom-property-image'>
                        <img src='../{$row['image_path']}' alt='{$row['name']}'>
                        <span class='custom-status-badge {$statusClass}'>{$row['status']}</span>
                    </div>
                    <div class='custom-property-info'>
                        <h3>{$row['name']}</h3>
                        <p class='custom-location'><i class='bx bx-map'></i> {$row['address']}</p>
                        <div class='custom-property-details'>
                            <div class='custom-detail'><i class='bx bx-dollar'></i> \${$row['price']}/month</div>
                            <div class='custom-detail'><i class='bx bx-bed'></i> {$row['bedrooms']} Beds</div>
                            <div class='custom-detail'><i class='bx bx-ruler'></i> {$row['size']} sqft</div>
                        </div>
                        <div class='custom-property-actions'>
                            <a href='edit-property.php?id={$row['id']}' class='custom-edit-btn'><i class='bx bx-edit'></i> Edit</a>
                            <a href='delete-property.php?id={$row['id']}' class='custom-delete-btn' onclick='return confirm(\"Are you sure you want to delete this property?\")'><i class='bx bx-trash'></i> Delete</a>
                        </div>
                    </div>
                </div>";
        }
    } else {
        echo "<p>No properties available at the moment.</p>";
    }
    ?>
</section>

<script src="js/script.js"></script>
</body>
</html>

<?php
$mysqli->close();
?>

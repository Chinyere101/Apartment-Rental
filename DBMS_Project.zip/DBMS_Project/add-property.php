<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $beds = $_POST['beds'];
    $sqft = $_POST['sqft'];
    $image_path = $_POST['image'];

    $status = 'Available';

    $stmt = $mysqli->prepare("INSERT INTO properties (name, address, price, bedrooms, size, image_path, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdiiss", $name, $address, $price, $beds, $sqft, $image_path, $status);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            header("Location: list-property.php");
            exit();
        } else {
            echo "No rows inserted. Check your data.";
        }
    } else {
        echo "Error: " . $stmt->error;
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Property - BEAPART</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>

<header>
    <a href="index.html" class="logo">
        <img src="image/logo.png">
    </a>
    <ul class="navbar">
        <li><a href="index.html">Home</a></li>
        <li><a href="list-property.php" class="active">My Properties</a></li>
        <li><a href="application.html">Applications</a></li>
    </ul>
    <div class="h-btn">
        <a href="login.php" class="logout-btn">
            <i class='bx bx-log-out'></i> Logout
        </a>
        <div class="bx bx-menu" id="menu-icon"></div>
    </div>
</header>

<section class="application-form">
    <h1>Add New Property</h1>

    <form id="propertyForm" action="add-property.php" method="POST">
        <div class="form-group">
            <label>Property Name</label>
            <input type="text" name="name" required>
        </div>

        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" required>
        </div>

        <div class="form-group">
            <label>Monthly Rent ($)</label>
            <input type="number" name="price" required>
        </div>

        <div class="form-group">
            <label>Bedrooms</label>
            <input type="number" name="beds" required>
        </div>

        <div class="form-group">
            <label>Square Footage</label>
            <input type="number" name="sqft" required>
        </div>

        <div class="form-group">
            <label>Image URL</label>
            <input type="text" name="image" required>
        </div>

        <button type="submit" class="submit-btn">Submit Property</button>
    </form>
</section>

<script src="js/script.js"></script>
</body>
</html>

<?php

$mysqli->close();
?>

<?php
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if (!isset($_GET['id'])) {
    echo "Property not found.";
    exit;
}

$id = intval($_GET['id']);
$stmt = $mysqli->prepare("SELECT * FROM properties WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Property not found.";
    exit;
}

$property = $result->fetch_assoc();
$mysqli->close();

$officialLinks = [
    "Collective" => "https://www.collectivelubbock.com",
    "Park East Apartments" => "https://www.liveparkeast.com",
    "Thrive Student Living" => "https://www.thrivestudentliving.com",
    "The Holly" => "https://www.hollylubbock.com",
    "Scarlet" => "https://www.livescarlet.com",
    "The Wyatt" => "https://www.thewyattlubbock.com",
    "Raider Pass" => "https://www.raiderpass.com",
    "The One" => "https://www.theonelubbock.com",
    "21 Hundred" => "https://www.live21hundred.com"
];

$propertyName = htmlspecialchars($property['name']);
$officialWebsite = $officialLinks[$propertyName] ?? "#";

$thumbnails = [
    "Collective" => [
        "image/apartments/collect.jpg",
        "image/apartments/collbath.jpg",
        "image/apartments/collpool.jpeg",
        "image/apartments/collroom.jpg"
    ],
    "Park East Apartments" => ["image/apartments/p2.jpg"],
    "Thrive Student Living" => ["image/apartments/p1.jpg"],
    "The Holly" => ["image/apartments/holly.jpeg"],
    "Scarlet" => ["image/apartments/scarlet.jpg"],
    "The Wyatt" => ["image/apartments/wyatt.png"],
    "Raider Pass" => ["image/apartments/raider.jpg"],
    "The One" => ["image/apartments/one.avif"],
    "21 Hundred" => ["image/apartments/21hun.avif"]
];
$currentThumbnails = $thumbnails[$propertyName] ?? ["image/default-property.jpg"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $propertyName; ?> - BEAPART</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>

<header>
    <a href="index.html" class="logo">
        <img src="image/logo.png">
    </a>
    <ul class="navbar">
        <li><a href="index.html">Home</a></li>
        <li><a href="rent.php" class="active">Rent</a></li>
        <li><a href="roommates.html">Roommates</a></li>
        <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="h-btn">
        <a href="login.html" class="h-btn1">Logout</a>
        <div class="bx bx-menu" id="menu-icon"></div>
    </div>
</header>

<section class="property-detail">
    <div class="detail-container">
        <div class="property-gallery">
            <div class="main-image">
                <img src="<?php echo $currentThumbnails[0]; ?>" alt="<?php echo $propertyName; ?>">
            </div>
            <div class="thumbnail-container">
                <?php foreach ($currentThumbnails as $thumb): ?>
                    <img src="<?php echo $thumb; ?>" class="thumbnail active">
                <?php endforeach; ?>
            </div>
        </div>
        <div class="property-info">
            <h1><?php echo $propertyName; ?></h1>
            <p class="location"><i class='bx bx-map'></i> <?php echo htmlspecialchars($property['address']); ?></p>
            <div class="price-section">
                <span class="price">$<?php echo number_format($property['price']); ?>/month</span>
            </div>
            <div class="property-meta">
                <div class="meta-item"><i class='bx bx-bed'></i><span><?php echo htmlspecialchars($property['bedrooms']); ?> Bedroom<?php echo $property['bedrooms'] > 1 ? 's' : ''; ?></span></div>
                <div class="meta-item"><i class='bx bx-ruler'></i><span><?php echo htmlspecialchars($property['size']); ?> sqft</span></div>
            </div>
            <div class="property-description">
                <h2>About This Property</h2>
                <p><?php echo !empty($property['description']) ? nl2br(htmlspecialchars($property['description'])) : 'Beautiful apartment located in Lubbock, TX, perfect for students and families.'; ?></p>
                <h3>Features & Amenities</h3>
                <ul class="amenities-list">
                    <li><i class="bx bx-check"></i> Fitness Center</li>
                    <li><i class="bx bx-check"></i> Swimming Pool</li>
                    <li><i class="bx bx-check"></i> Private Balcony</li>
                    <li><i class="bx bx-check"></i> Study Lounges</li>
                </ul>
                <div class="property-actions">
                    <a href="<?php echo $officialWebsite; ?>" target="_blank" class="contact-btn"><i class='bx bx-globe'></i> Official Website</a>
                    <a href="applications.php?property=<?php echo urlencode($property['name']); ?>" class="apply-btn"><i class='bx bx-edit'></i> Apply Now</a>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="js/script.js"></script>
</body>
</html>
<?php
$mysqli = new mysqli("localhost", "root", "123Onyinye.", "beapart");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$id = $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $bedrooms = $_POST['bedrooms'];
    $size = $_POST['size'];
    $status = $_POST['status'];

    $stmt = $mysqli->prepare("UPDATE properties SET name=?, address=?, price=?, bedrooms=?, size=?, status=? WHERE id=?");
    $stmt->bind_param("ssdissi", $name, $address, $price, $bedrooms, $size, $status, $id);
    $stmt->execute();
    $stmt->close();
    $return = $_GET['return'] ?? 'list-property.php';
    header("Location: $return");
    exit();
}

$stmt = $mysqli->prepare("SELECT * FROM properties WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();
$stmt->close();
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Property</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <section class="add-property-form">
        <div class="form-container">
            <div class="form-header">
                <h1>Edit Property</h1>
                <p>Make updates to your property listing below.</p>
            </div>
            <form method="POST">
                <div class="form-group">
                    <label>Name:</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($property['name']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Address:</label>
                    <input type="text" name="address" value="<?= htmlspecialchars($property['address']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Price:</label>
                    <input type="number" step="0.01" name="price" value="<?= $property['price'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Bedrooms:</label>
                    <input type="number" name="bedrooms" value="<?= $property['bedrooms'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Size (sqft):</label>
                    <input type="number" name="size" value="<?= $property['size'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Status:</label>
                    <select name="status">
                        <option value="Available" <?= $property['status'] == 'Available' ? 'selected' : '' ?>>Available</option>
                        <option value="Unavailable" <?= $property['status'] == 'Unavailable' ? 'selected' : '' ?>>Unavailable</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="submit-btn">Save Changes</button>
                </div>
            </form>
        </div>
    </section>
</body>
</html>